def test_lose (abs,ord,tableau_ordi):
    return tableau_ordi[ord][abs]=="B"