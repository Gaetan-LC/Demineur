def affichage(tableau_jouer, taille_tableau):

    print("  ",end="")
    for i in range (1,taille_tableau+1):
        print(f"  {i} ", end="") #toute premier ligne qui affiche abs
    print("")#a la ligne

    for i in range(taille_tableau):
        print(" ", "-"*(4*taille_tableau+1), end="")
        print("\n", i+1, end="")

        for j in range(taille_tableau):
            print("|", tableau_jouer[i][j], "", end="")

        print("|")#a la ligne

    print(" ", "-"*(4*taille_tableau+1))