def test_win(tableau_jouer, tableau_ordi):

    """renvoie un bool si il y victoire ou pas"""

    test_victoire=[]    #une list qui contiendra des bool qui dis si chaque valeur est égale ou non

    for i in range (0,len(tableau_jouer[0])):
        test_victoire.extend(map(lambda tabJ,tabO: tabJ==tabO or tabO=="B",tableau_jouer[i],tableau_ordi[i]))
        #rajouter dans la list les iterables du mapping qui verifie si il y a les mêmes valeurs ou une bombe

    return all(test_victoire)