def tableau_ordi(taille_tableau):
    from random import randint
    from math import ceil
    
    nb_bombe = int(ceil(taille_tableau**2/3)) #le tableau sera carré il aura le 1/3 de bombe par rapport au nombre de case total
    #ceil arrondi vers le haut

    """creation d'un tableau_ordi vide 4x4"""

    tableau_ordi=[]
    for i in range (taille_tableau):
        tableau_ordi.append([])
        for j in range(taille_tableau):
            tableau_ordi[i].append(" ")
    

    """ajout de bombe"""        
    
    a=0
    while a < nb_bombe :
        x=randint(0,len(tableau_ordi)-1)
        y=randint(0,len(tableau_ordi[0])-1)
        if tableau_ordi[x][y] != "B" :
            tableau_ordi[x][y]="B"
            a+=1


    """ajout chiffres"""

    for i in range(len(tableau_ordi)):
        for j in range(len(tableau_ordi[0])):

            if not tableau_ordi[i][j] == "B":
                n=0



                if not i==0:            #en haut
                    if tableau_ordi[i-1][j]=="B":
                        n+=1
                   
                if not i==0 and not j==len(tableau_ordi[0])-1: #haut droit
                    if tableau_ordi[i-1][j+1]=="B":
                        n+=1
                
                if not j==len(tableau_ordi[0])-1:   #droite
                    if tableau_ordi[i][j+1]=="B":
                        n+=1
                        
                if not i==len(tableau_ordi)-1 and not j==len(tableau_ordi[0])-1: #bas droite
                    if tableau_ordi[i+1][j+1]=="B":
                        n+=1
                
                if not i==len(tableau_ordi)-1: #bas
                    if tableau_ordi[i+1][j]=="B":
                        n+=1
                        
                if not i==len(tableau_ordi)-1 and not j==0: #bas gauche
                    if tableau_ordi[i+1][j-1]=="B":
                        n+=1
                        
                if not j==0: #gauche
                    if tableau_ordi[i][j-1]=="B":
                        n+=1
                    
                if not i==0 and not j==0: #haut gauche
                    if tableau_ordi[i-1][j-1]=="B":
                        n+=1
                
                tableau_ordi[i][j]=n

    return tableau_ordi, nb_bombe