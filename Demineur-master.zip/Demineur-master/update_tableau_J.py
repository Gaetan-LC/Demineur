def update_tableau_J(abs,ord, need_flag,tableau_jouer, tableau_ordi):
    #les abs sont les colones! alors que les ord sont les ligne!
    if need_flag and tableau_jouer[ord][abs]==" ":
        tableau_jouer[ord][abs]="F"
    elif not need_flag:
        tableau_jouer[ord][abs]=tableau_ordi[ord][abs]
        

    return tableau_jouer