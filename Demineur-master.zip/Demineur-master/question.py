def coordonee(taille_tableau):

    """renvoie abs, ord"""

    correct_awnser=False
    need_flag=False

    while not correct_awnser:

        #question
        question=input("type coordinates (abs space ord (space 'f')): ")
        
        #test si il y a un espace
        if not " " in question:
            print("you did not put the space")
            continue

        #regarde si l'utilisateur demande un drapeau
        try:
            abs, ord, flag = question.split()
        except ValueError:#si non il dis qu'il n'en a pas besoin
            abs, ord= question.split()
            need_flag=False
        else:
            #si oui il verifie que l'utilisateur a bien mis "f"
            if "f" in flag.lower():
                need_flag=True
            elif not "f" in flag.lower():
                print("need to put 'f'")
                del flag
                continue

        #test si valeur son des nombres
        try:
            abs=int(abs)
        except ValueError:
            print("not a number!")
            continue

        try:
            ord=int(ord)
        except ValueError:
            print("not a number!")
            continue
        
        print(f"absice: {abs} et ordonnee: {ord}")

        #verifie que les valeurs corresponde au npbre de colonne et ligne disponible
        if 1<=abs<=taille_tableau and 1<=ord<=taille_tableau:
            abs-=1
            ord-=1
            correct_awnser=True
            continue
        else:
            print("number is not between 1 and 4!")
        
    return abs, ord, need_flag