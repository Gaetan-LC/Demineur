from affichage import affichage
from tableau_ordi import tableau_ordi
from update_tableau_J import update_tableau_J
from win import test_win
from question import coordonee
from lose import test_lose


play_again=True
while play_again:
    #verifie que la reponse de la taille du tableau est acceptable
    correct_awnser=False
    while not correct_awnser:
        try:
            taille_tableau=int(input("size of the board(3 min, 6 max): "))
        except ValueError:
            print("not a number")
            continue
        else:
            if 2<taille_tableau<=6:
                correct_awnser=True
                continue
            else:
                print("number not between 3 and 6")


    #ici je crée le tableau du jouer
    tableau_J=[]
    for i in range (taille_tableau):  #Changer ici
        tableau_J.append([])
        for j in range(taille_tableau):
            tableau_J[i].append(" ")


    #creation du tableau de l'ordi
    tableau_O, nb_bombe=tableau_ordi(taille_tableau)

    #affiche le tableau du jouer pour la premier fois pour permettre au jouer de choisir
    affichage(tableau_J,taille_tableau)


    #le jeu commence
    win=False
    lose=False
    while not win and not lose:

        print(f"total number of bombs {nb_bombe}")

        #demande les coordonnées
        abs, ord, need_flag = coordonee(taille_tableau)

        #mise a jour de ce que vois le jouer sur son tableau
        tableau_J = update_tableau_J(abs, ord,need_flag, tableau_J, tableau_O)

        #montre au jouer ce qu'il y en dessous de la case choisi
        affichage(tableau_J,taille_tableau)


        #verifie si il y a victoire ou defaite
        if test_win(tableau_J,tableau_O):
            win=True
            print("you win!!!")
            continue

        if not need_flag:
            if test_lose(abs, ord, tableau_O):
                lose=True
                print("you lose :(")
                continue
    
    correct_awnser_play_again=False
    while not correct_awnser_play_again:
        play_again_q=input("do you wish to play again? y/n?: ").lower()

        if play_again_q=="y" or play_again_q=="yes":
            correct_awnser_play_again=True
            continue

        elif play_again_q=="n" or play_again_q=="no":
            correct_awnser_play_again=True
            play_again=False
            continue

        else:
            print("did not understand your request")
            continue